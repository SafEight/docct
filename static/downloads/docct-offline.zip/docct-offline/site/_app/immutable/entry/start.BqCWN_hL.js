import{l as o,s as r}from"../chunks/DOAiEt7A.js";export{o as load_css,r as start};
